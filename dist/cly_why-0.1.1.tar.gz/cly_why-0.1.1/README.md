# Why?
I wanted a simple library to write small to moderate cli programs

# Why not X?
## X = argparse
Its way more then what I need 99% of the time.

## X = click
I don't particularly like decorators.

## X = typer
I've used typer a bit, but it never clicked with me.

# Feature List
- [ ] Tests
- [X] Colorize and Text Decorate
- [ ] 
- [ ] 
